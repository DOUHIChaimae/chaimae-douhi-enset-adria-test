package ma.enset.walletservice;

import ma.enset.walletservice.entities.Wallet;
import ma.enset.walletservice.repository.WalletRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;

import java.util.Date;
import java.util.List;
import java.util.Random;

@SpringBootApplication
public class WalletServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(WalletServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner start(WalletRepository walletRepository,
                            RepositoryRestConfiguration repositoryRestConfiguration) {
        repositoryRestConfiguration.exposeIdsFor(Wallet.class);
        return args -> {
            Random random = new Random();
            for (int i = 0; i < 10; i++) {
                walletRepository.saveAll(List.of(
                        Wallet.builder()
                                .currency("Currency" + i)
                                .balance(180 + Math.random() * 10000)
                                .creationDate(new Date())
                                .build()
                ));
            }

            walletRepository.findAll().forEach(
                    wallet -> System.out.println(wallet.toString()));
        };
    }

}

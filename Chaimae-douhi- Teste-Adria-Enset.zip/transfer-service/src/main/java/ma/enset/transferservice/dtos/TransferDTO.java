package ma.enset.transferservice.dtos;

import lombok.Data;
import ma.enset.transferservice.enums.STATUS;

import java.util.Date;

@Data
public class TransferDTO {
    private String id;
    private Date date;
    private double amount;
    private STATUS status;
}

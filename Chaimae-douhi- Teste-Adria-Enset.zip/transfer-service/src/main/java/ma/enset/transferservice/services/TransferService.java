package ma.enset.transferservice.services;
import ma.enset.transferservice.dtos.TransferDTO;

import java.util.List;

public interface TransferService {
    List<TransferDTO> listTransferts();
}

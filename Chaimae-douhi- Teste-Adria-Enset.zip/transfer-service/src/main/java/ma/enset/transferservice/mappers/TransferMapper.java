package ma.enset.transferservice.mappers;

import ma.enset.transferservice.dtos.TransferDTO;
import ma.enset.transferservice.entities.Transfert;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public final class TransferMapper {

    public static TransferDTO fromTransfer(Transfert transfer) {
        TransferDTO transferDto = new TransferDTO();
        BeanUtils.copyProperties(transfer, transferDto);
        return transferDto;
    }

}

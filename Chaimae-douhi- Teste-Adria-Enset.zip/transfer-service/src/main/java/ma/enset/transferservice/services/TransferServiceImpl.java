package ma.enset.transferservice.services;


import ma.enset.transferservice.dtos.TransferDTO;
import ma.enset.transferservice.entities.Transfert;
import ma.enset.transferservice.mappers.TransferMapper;
import ma.enset.transferservice.repository.TransferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransferServiceImpl implements TransferService {
    @Autowired
    TransferRepository transferRepository;

    @Override
    public List<TransferDTO> listTransferts() {
        List<Transfert> transferts = transferRepository.findAll();
        List<TransferDTO> transferDTOS = transferts.stream()
                .map(TransferMapper::fromTransfer)
                .collect(Collectors.toList());

        return transferDTOS;
    }
}

package ma.enset.walletservice.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class Wallet {
    @Id
    private UUID id;
    private double balance;
    private Date creationDate;
    private String currency;

}

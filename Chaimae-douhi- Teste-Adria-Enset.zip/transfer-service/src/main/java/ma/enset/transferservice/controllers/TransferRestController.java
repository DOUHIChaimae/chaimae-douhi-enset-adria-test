package ma.enset.transferservice.controllers;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import ma.enset.transferservice.dtos.TransferDTO;
import ma.enset.transferservice.services.TransferService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@Slf4j
@CrossOrigin("*")
public class TransferRestController {

    private TransferService transferService;

    @GetMapping("/transfers")
    public ResponseEntity<List<TransferDTO>> transfers() {
        return ResponseEntity.ok(transferService.listTransferts());
    }

}

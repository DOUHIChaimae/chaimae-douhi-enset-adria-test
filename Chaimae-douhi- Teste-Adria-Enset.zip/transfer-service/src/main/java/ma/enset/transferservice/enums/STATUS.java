package ma.enset.transferservice.enums;

public enum STATUS {
    PENDIND, VALIDATED, REJECTED
}

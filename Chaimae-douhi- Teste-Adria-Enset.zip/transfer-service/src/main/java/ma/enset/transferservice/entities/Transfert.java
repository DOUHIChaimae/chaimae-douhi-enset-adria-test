package ma.enset.transferservice.entities;

import jakarta.persistence.Id;
import ma.enset.transferservice.enums.STATUS;

import java.util.Date;

public class Transfert {
    @Id
    private String id;

    private Date date;
    private String sourceWalletId;
    private String destinationWalletId;
    private double amount;
    private STATUS status;

}
